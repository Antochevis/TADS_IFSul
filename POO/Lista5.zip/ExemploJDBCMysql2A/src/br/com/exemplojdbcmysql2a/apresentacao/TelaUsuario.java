package br.com.exemplojdbcmysql2a.apresentacao;

public class TelaUsuario {
	
	public void cadastrar() {
		System.out.println("Digite seu nome");
		// ler o nome no scanner
		System.out.println("Digite seu email");
		// ler o email
		System.out.println("Digite seu senha");
		// ler a senha
		
		
	}

}
