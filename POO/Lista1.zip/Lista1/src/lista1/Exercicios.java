package lista1;

import java.util.Scanner;
import java.util.Arrays;

public class Exercicios {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);

//		Exercício 1
//		exibirMensagem();
		
//		Exercício 2
//		int soma = somarCincoEDez();
//		System.out.println("A soma de 5 e 10 é = " + soma + ".");
		
//		Exercício 3
//		System.out.println("Digite seu nome:");
//		String nome = teclado.nextLine();
//		saudacao(nome);
		
//		Exercício 4
//		System.out.println("Digite um número inteiro para descobrir o seu dobro:");
//		int numero = teclado.nextInt();
//		int resultado = dobro(numero);
//		System.out.printf("O dobro de %d é %d", numero, resultado);
		
//		Exercício 5
//		System.out.println("Digite dois números inteiros em sequência para descobrir sua média aritmética: ");
//		int num1 = teclado.nextInt();
//		int num2 = teclado.nextInt();
//		double resultado = media(num1, num2);
//		System.out.printf("A médica aritmética de %d e %d é %.2f", num1, num2, resultado);
		
//		Exercício 6
//		System.out.println("Digite um número inteiro para descobrir se ele é par: ");
//		int numero = teclado.nextInt();
//		boolean resultado = ehPar(numero);
//		System.out.println(resultado);
		
//		Exercício 7
//		System.out.println("Digite dois números inteiros em sequência para descobrir qual é o maior número: ");
//		int numero1 = teclado.nextInt();
//		int numero2 = teclado.nextInt();
//		int resultado = maiorNumero(numero1, numero2);
//		System.out.printf("O maior número entre %d e %d é o número %d", numero1, numero2, resultado);
		
//		Exercício 8
//		System.out.println("Digite dois números inteiros em sequência (base e expoente) para descobrir a potência: ");
//		int numeroBase = teclado.nextInt();
//		int numeroExpoente = teclado.nextInt();
//		double resultado = potencia(numeroBase, numeroExpoente);
//		System.out.printf("O resultado da potência é %.0f", resultado);
		
//		Exercício 9
//		System.out.println("Digite um número inteiro para descobrir sua tabela de 1 a 10: ");
//		int numero = teclado.nextInt();
//		tabuada(numero);
		
//		Exercício 10
//		System.out.println("Digite um número inteiro para descobrir seu fatorial: ");
//		int numero = teclado.nextInt();
//		int resultado = fatorial(numero);
//		System.out.printf("%d! = %d", numero, resultado);
		
//		Exercício 11
//		System.out.println("Digite quantas posições você quer preencher numa lista: ");
//		int tamanhoArray = teclado.nextInt();
//		int[] numerosArray = new int[tamanhoArray];
////		
//		System.out.printf("Digite %d números inteiros para preencher a lista e descobrir o resultado da soma de todos os números: \n", tamanhoArray);
//		for (int i = 0; i < tamanhoArray; i++) {
//			numerosArray[i] = teclado.nextInt();
//        }
//		
//		int resultado = somaArray(numerosArray);
//		System.out.printf("A soma de todos os números da lista é = " + resultado);
		
//		Exercício 12
//		System.out.println("Digite um número inteiro de três dígitos para descobrir o seu inverso: ");
//		int numero = teclado.nextInt();
//		int resultado = inverterNumero(numero);
//		System.out.printf("O inverso de %d é %d", numero, resultado);
		
//		Exercício 13
//		System.out.println("Digite uma frase para descobrir quantas vogais ela possui: ");
//		String frase = teclado.nextLine();
//		int resultado = contarVogais(frase);
//		System.out.printf("A frase que você digitou tem %d vogais", resultado);
		
//		Exercício 14
//		System.out.println("Digite um número inteiro para verificar se ele é um número primo: ");
//		int numero = teclado.nextInt();
//		boolean resultado = ehPrimo(numero);
//		System.out.println("'true' se é primo e 'false' se não é primo: " + resultado);
		
//		Exercício 15
//		System.out.println("Digite quantos números você quer ver da sequência de fibonacci: ");
//		int n = teclado.nextInt();
//		int[] resultado = fibonacci(n);
//		
//		for (int i = 0; i < resultado.length; i++) {
//            System.out.print(resultado[i] + " ");
//        }
		
//		Exercício 16
//		System.out.println("Digite quantos números você quer adicionar na lista: ");
//		int tamanhoArray = teclado.nextInt();
//		int[] numerosArray = new int[tamanhoArray];
//		
//		System.out.println("Digite os dígitos que estarão presentes na lista e que serão retornados ordenados em ordem crescente: ");
//		for (int i = 0; i < tamanhoArray; i++) {
//			numerosArray[i] = teclado.nextInt();
//        }
//		
//		int[] numerosOrdenados = ordenarArray(numerosArray);
//		
//		for (int numero : numerosOrdenados) {
//            System.out.println(numero);
//        }
		
//		Exercício 17
//		System.out.println("Digite uma temperatura em Celsius para descobrir seu valor em Fahrenheit: ");
//		double grausCelsius = teclado.nextDouble();
//		double grausFahrenheit = celsiusParaFahrenheit(grausCelsius);
//		System.out.printf("%.1f°C = %.1f°F", grausCelsius, grausFahrenheit);
		
//		Exercício 18
//		System.out.println("Digite quantos números você quer adicionar na lista: ");
//		int tamanhoArray = teclado.nextInt();
//		int[] numerosArray = new int[tamanhoArray];
//	
//		System.out.println("Digite os dígitos que estarão presentes na lista: ");
//		for (int i = 0; i < tamanhoArray; i++) {
//			numerosArray[i] = teclado.nextInt();
//        }
//		
//		int resultado = segundoMaior(numerosArray);
//		System.out.println("O segundo maior número da lista é o número " + resultado);

//		Exercício 19
//		System.out.println("Digite uma palavra para descobrir se ela é palíndromo: ");
//		String palavra = teclado.nextLine();
//		boolean resultado = ehPalindromo(palavra);
//		System.out.println("'true' se é palíndromo e 'false' se não é: " + resultado);
		
//		Exercício 20
//		System.out.println("Digite dois números inteiros para descobrir o MDC deles: ");
//		int a = teclado.nextInt();
//		int b = teclado.nextInt();
//		int resultado = mdc(a, b);
//		System.out.printf("O MDC de %d e %d é %d", a, b, resultado);		
	}
	
	public static void exibirMensagem() {
		System.out.println("Bem-vindo à prática de métodos!");
	}
	
	public static int somarCincoEDez() {
		return 5 + 10;
	}
	
	public static void saudacao(String nome) {
        System.out.println("Olá, " + nome + "!");
    }
	
	public static int dobro(int numero) {
		return numero * 2;
	}
	
	public static double media(int n1, int n2) {
		double media = (n1+n2)/2.0;
		return media;
	}
	
	public static boolean ehPar(int numero) {
        return numero % 2 == 0;
    }
	
	public static int maiorNumero(int n1, int n2) {
        if (n1 > n2) {
            return n1;
        } else {
            return n2;
        }
    }
	
	public static double potencia(int base, int expoente) {
		double resultado = Math.pow(base, expoente);
        return resultado;
    }
	
	public static void tabuada(int num) {
        for (int i = 1; i <= 10; i++) {
            System.out.println(num + " x " + i + " = " + (num * i));
        }
    }
	
	public static int fatorial(int num) {
        int resultadoFatorial = 1;
        
        for (int i = 1; i <= num; i++) {
        	resultadoFatorial *= i;
        }
        
        return resultadoFatorial;
    }
	
	public static int somaArray(int[] numeros) {
        int soma = 0;
        
        for (int i = 0; i < numeros.length; i++) {
            soma += numeros[i];
        }
        
        return soma;
    }
	
	public static int inverterNumero(int num) {
        int unidade = num % 10;
        int dezena = (num / 10) % 10;
        int centena = (num / 100) % 10;
        
        return unidade * 100 + dezena * 10 + centena;
    }
	
	public static int contarVogais(String frase) {
        int contadorVogais = 0;
        
        frase = frase.toLowerCase();
        
        for (int i = 0; i < frase.length(); i++) {
            char caractere = frase.charAt(i);
            
            if (caractere == 'a' || caractere == 'e' || caractere == 'i' || caractere == 'o' || caractere == 'u') {
            	contadorVogais++;
            }
        }
        
        return contadorVogais;
    }
	
	public static boolean ehPrimo(int num) {
        if (num <= 1) {
            return false;
        }

        for (int i = 2; i <= (num - 1); i++) {
            if (num % i == 0) {
                return false;
            }
        }

        return true;
    }
	
	public static int[] fibonacci(int n) {
        int[] arrayFibonacci = new int[n];

        arrayFibonacci[0] = 1;
        
        if (n > 1) {
        	arrayFibonacci[1] = 1;
        }

        for (int i = 2; i < n; i++) {
        	arrayFibonacci[i] = arrayFibonacci[i - 1] + arrayFibonacci[i - 2];
        }

        return arrayFibonacci;
    }
	
	public static int[] ordenarArray(int[] numeros) {
        Arrays.sort(numeros);
        return numeros;
    }
	
	public static double celsiusParaFahrenheit(double celsius) {
        return (celsius * 1.8) + 32;
    }
	
	public static int segundoMaior(int[] numeros) {
        Arrays.sort(numeros);
        return numeros[numeros.length - 2];
    }

	public static boolean ehPalindromo(String palavra) {
        String palavraInvertida = new StringBuilder(palavra).reverse().toString();
        return palavra.equals(palavraInvertida);
    }
	
	public static int mdc(int a, int b) {
//		dividir o número maior pelo menor, se o resto for zero então o número menor é o MDC.
//		senão pegar o resto da divisão e dividir pelo menor número, se o resto for zero então o divisor é o MDC.
		
		if (a >= b) {
			while (b != 0) {
	            int temp = b;
	            b = a % b;
	            a = temp;
	        }
	        return a;
		} else {
			while (a != 0) {
	            int temp = a;
	            a = b % a;
	            b = temp;
	        }
	        return b;
		}
    }

}

